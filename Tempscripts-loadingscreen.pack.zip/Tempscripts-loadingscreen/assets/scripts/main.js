// Voeg deze variabelen toe aan het begin van je script
var gameLoaded = false;
var minTimeElapsed = false;
const minDisplayTime = 60 * 1000; // 60 seconden in milliseconden

// --- WEBAUDIO API VARIABELEN VOOR MUZIEK ANALYSE ---
let audioContext;
let analyser;
let sourceNode; // Zorg dat deze globaal is
let frequencyData;
const logoElementSelector = '.overlay .container > .loader > .logo'; // Selector voor je logo element

// --- NIEUWE VARIABELEN VOOR KLEURVERANDERING OP "BEAT" ---
const rainbowColors = [
    'rgba(255,0,0,0.9)',     // Rood
    'rgba(255,127,0,0.9)',   // Oranje
    'rgba(255,255,0,0.9)',   // Geel
    'rgba(0,255,0,0.9)',     // Groen
    'rgba(0,0,255,0.9)',     // Blauw
    'rgba(75,0,130,0.9)',    // Indigo
    'rgba(148,0,211,0.9)'    // Violet
];
let currentColorIndex = 0;
let lastBeatTime = 0;
const beatCooldown = 150; // Milliseconden cooldown tussen kleurveranderingen

// --- AANGEPASTE GLOED INTENSITEIT EN GEVOELIGHEID ---
const beatThreshold = 30; // VERLAAGD: Reageert op kleinere geluidjes
const baseGlowBlur = 15; // AANGEPAST: Minimaal 15px blur voor dikte bij stilte
const maxGlowBlur = 80; // VERHOOGD: Veel meer maximale blur voor intensiteit
const baseGlowSpread = 15; // AANGEPAST: Minimaal 15px spread voor dikte bij stilte
const maxGlowSpread = 80; // VERHOOGD: Kan heel breed worden (ongeveer 3cm visueel)
// --- EINDE AANGEPASTE GLOED INTENSITEIT ---

// --- NIEUWE VARIABELEN VOOR VIDEO SWIPER ---
const videoLinks = [
    { url: "https://www.youtube.com/embed/uzmDWJrVchk?autoplay=1&controls=0&mute=1&loop=1&playlist=uzmDWJrVchk", title: "ALLES KAN KAPOT!" },
    { url: "https://www.youtube.com/embed/IB2cwpfvrkw?autoplay=1&controls=0&mute=1&loop=1&playlist=IB2cwpfvrkw", title: "Dromendans" }
];
let currentVideoIndex = 0;
const youtubePlayer = document.getElementById("youtube-player");
const videoTitleElement = document.querySelector(".video-swiper-container .video-title");

var song; // Declareer 'song' globaal

// Functie om de video en het bijbehorende nummer te wisselen
function changeVideo(index) {
    if (index >= 0 && index < videoLinks.length) {
        currentVideoIndex = index;
        youtubePlayer.src = videoLinks[currentVideoIndex].url;
        videoTitleElement.textContent = videoLinks[currentVideoIndex].title;

        // Stop het huidige nummer, laad het nieuwe nummer en speel het af
        if (song) {
            song.pause();
            song.currentTime = 0;
            // BELANGRIJK: Ontkoppel de oude sourceNode hier als deze bestaat
            if (sourceNode) {
                sourceNode.disconnect();
            }
        }

        // Zorg ervoor dat Config.Songs de juiste index heeft
        if (Config.Songs && Config.Songs[currentVideoIndex]) {
            song = new Audio("assets/media/" + Config.Songs[currentVideoIndex]);
            song.loop = true; // Zorg dat het nummer in een loop speelt
            song.play();
            // Stel volume in op basis van de slider
            if ($('#volumeSlider').length) {
                song.volume = $('#volumeSlider').val() / 100;
            }

            // Herinitialiseer Web Audio API als de source verandert
            // Deze stap is cruciaal voor de RGB gloed
            if (audioContext) { // Controleer of audioContext al geïnitialiseerd is
                sourceNode = audioContext.createMediaElementSource(song); // Maak een nieuwe source van het nieuwe nummer
                sourceNode.connect(analyser); // Verbind de nieuwe source met de analyser
                analyser.connect(audioContext.destination); // Verbind de analyser met de output
            }
        } else {
            console.warn(`Geen muziek gevonden voor video-index ${currentVideoIndex}.`);
            // Optioneel: Als er geen muziek is, zet de gloed dan uit
            const logoElement = document.querySelector(logoElementSelector);
            if (logoElement) {
                logoElement.style.boxShadow = `0 0 0px 0px rgba(0,0,0,0)`;
            }
        }
    }
}


$("#read-more").on("click", function() {
    let newHeight = $(".information .description > p").height();

    $("#collapse").fadeIn(150);
    $(this).fadeOut(150);

    $(".information .description").css("height", newHeight + "px")
})

$("#collapse").on("click", function() {
    $("#read-more").fadeIn(150);
    $(this).fadeOut(150);

    $(".information .description").css("height", "");
})

$(".hideoverlay .bind").html(Config.CustomBindText == "" ? String.fromCharCode(Config.HideoverlayKeybind).toUpperCase() : Config.CustomBindText)

$(document).on('mousemove', function(e) {
    $('#cursor').css({top: e.pageY + 'px', left: e.pageX + 'px'});
});

var overlay = true;
$(document).keydown(function(e) {
    if(e.which == Config.HideoverlayKeybind) {
        overlay = !overlay;
        if(!overlay) {
            $(".overlay").css("opacity", ".0")
        } else {
            $(".overlay").css("opacity", "")
        }
    }
})


function setup() {
    let currentDate = new Date();

    // --- NIEUWE LOGICA VOOR MINIMALE LAADTIJD (binnen setup) ---
    setTimeout(() => {
        minTimeElapsed = true;
        checkAndShutdown();
    }, minDisplayTime);
    // --- EINDE NIEUWE LOGICA ---

    let year = currentDate.getFullYear();
    let month = (currentDate.getMonth() + 1) < 10 ? "0" + (currentDate.getMonth() + 1) : (currentDate.getMonth() + 1);
    let day = currentDate.getDate() < 10 ? "0" + currentDate.getDate() : currentDate.getDate();
    $("#date").html(year + "-" + month + "-" + day)

    // Online player count
    fetch("http://" + Config.ServerIP + "/info.json").then(res => res.json()).then(info => {
        fetch("http://" + Config.ServerIP + "/players.json").then(res => res.json()).then(players => {
            $("#clients").html(players.length + "/" + info.vars.sv_maxClients)
        })
    })

    // --- WEBAUDIO API INITIALISATIE VOOR MUZIEK ANALYSE ---
    // Deze sectie initialiseert de context en analyser EENMALIG.
    // De sourceNode wordt later in changeVideo aangemaakt en verbonden.
    try {
        audioContext = new (window.AudioContext || window.webkitAudioContext)();
        analyser = audioContext.createAnalyser();
        analyser.fftSize = 256;
        frequencyData = new Uint8Array(analyser.frequencyBinCount);

        // De sourceNode verbinding wordt nu volledig afgehandeld in changeVideo().
        // Hier hoeft GEEN sourceNode te worden aangemaakt of verbonden.

        updateGlow(); // Start de glow animatieloop
    } catch (e) {
        console.error("Web Audio API is niet ondersteund of initialisatie mislukt:", e);
        const logoElement = document.querySelector(logoElementSelector);
        if (logoElement) {
             logoElement.style.boxShadow = '0 0 25px 10px rgba(255,0,0,0.9)';
        }
    }
    // --- EINDE WEBAUDIO API INITIALISATIE ---

    // Categories
    var currentCat = "";
    Config.Categories.forEach((cat, index) => {
        $(".categories .buttons").append(`<p data-category="${index}" class="${cat.default ? "active" : ""}">${cat.label}</p>`)
        if(cat.default) currentCat = index;

        $(".categories .carousel > *").css("transform", `translateX(-${currentCat * 100}%)`)
    });

    $(".categories .buttons p").on("click", function() {
        $(`.categories .buttons p[data-category="${currentCat}"]`).removeClass("active");
        currentCat = $(this).attr("data-category");
        $(`.categories .buttons p[data-category="${currentCat}"]`).addClass("active");

        $(".categories .carousel > *").css("transform", `translateX(-${currentCat * 100}%)`)
    });

    // Socials
    Config.Socials.forEach((social, index) => {
        $(".categories .socialmedia").append(`<div class="box" data-id="${social.name}" data-link="${social.link}"><img class="icon" src="${social.icon}"><div class="info"><p class="title">${social.label}</p><p class="description">${social.description}</p></div></div>`)
    });

    var copyTimeouts = {};
    $(".categories .socialmedia .box").on("click", function() {
        let id = $(this).data("id")
        let link = $(this).data("link")
        if(copyTimeouts[id]) clearTimeout(copyTimeouts[id]);

        window.open(link, '_blank', 'toolbar=0,location=0,menubar=0');
        //copyToClipboard(link)

        $(this).addClass("copied");
        copyTimeouts[id] = setTimeout(() => {
            $(this).removeClass("copied")
            copyTimeouts[id] = undefined;
        }, 1000);
    })

    // Carousel
    Config.Staff.forEach((member, index) => {
        $(".staff .innercards").append(`<div class="card" data-id="${index}" style="--color: ${member.color}">
            <p class="name">${member.name}</p>
            <p class="description">${member.description}</p>
            <img class="avatar" src="${member.image}">
        </div>`);
        if(index < Config.Staff.length - 1) {
            $(".staff .pages").append(`<div data-id="${index}"></div>`);
        }
        $(`.staff .pages > div[data-id="0"]`).addClass("active")

        if(Config.Staff.length < 3) {
            $(".staff .pages").hide();
            $(".staff .previous").hide();
            $(".staff .next").hide();
        }
    })

    var currentPage = 0;
    $(".staff .next").on("click", function() {
        if(currentPage < Config.Staff.length - 2) {
            $(`.staff .pages > div[data-id="${currentPage}"]`).removeClass("active");
            currentPage++;
            $(`.staff .pages > div[data-id="${currentPage}"]`).addClass("active");
            $(".staff .innercards").css("transform", `translate3d(calc(-${currentPage * 50}% - ${(currentPage+1) * .5}vw), 0, 0)`)
        }
    });

    $(".staff .previous").on("click", function() {
        if(currentPage > 0) {
            $(`.staff .pages > div[data-id="${currentPage}"]`).removeClass("active");
            currentPage--;
            $(`.staff .pages > div[data-id="${currentPage}"]`).addClass("active");
            $(".staff .innercards").css("transform", `translate3d(calc(-${currentPage * 50}% - ${(currentPage+1) * .5}vw), 0, 0)`)
        }
    });

    // --- Initialiseer de video swiper ---
    changeVideo(0); // Start met de eerste video en het bijbehorende nummer

    $(".swiper-button-next").on("click", function() {
        changeVideo((currentVideoIndex + 1) % videoLinks.length);
    });

    $(".swiper-button-prev").on("click", function() {
        changeVideo((currentVideoIndex - 1 + videoLinks.length) % videoLinks.length);
    });
    // --- Einde video swiper initialisatie ---
}

function loadProgress(progress) {
    $(".loader .filled-logo").css("height", progress + "%");
    $(".loader .progress").html(progress + "%");

    // --- NIEUWE LOGICA VOOR MINIMALE LAADTIJD (binnen loadProgress) ---
    if (progress === 100) {
        gameLoaded = true;
        checkAndShutdown();
    }
    // --- EINDE NIEUWE LOGICA ---
}

window.addEventListener('message', function(e) {
    if(e.data.eventName === 'loadProgress') {
        loadProgress(parseInt(e.data.loadFraction * 100));
    }
});

var tag = document.createElement('script');

tag.src = "https://www.youtube.com/iframe_api"; // Dit is de correcte, veilige YouTube IFrame API URL
var firstScriptTag = document.getElementsByTagName('script')[0];
firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

var player;
function onYouTubeIframeAPIReady() {
    player = new YT.Player("youtube-player", {
        events: {
            'onReady': onPlayerReady
        }
    });
}

function onPlayerReady() {
    player.mute(); // YouTube player start muted
    player.setVolume(0); // Extra zekerheid dat YouTube player muted is
}

function copyToClipboard(text) {
    const body = document.querySelector('body');
    const area = document.createElement('textarea');
    body.appendChild(area);

    area.value = text;
    area.select();
    document.execCommand('copy');

    body.removeChild(area);
}

// --- NIEUWE FUNCTIE: MUZIEK ANALYSE EN GLOED UPDATE ---
function updateGlow() {
    if (analyser && frequencyData) {
        analyser.getByteFrequencyData(frequencyData); // Krijg frequentiegegevens

        let sum = 0;
        // Bereken de gemiddelde amplitude (volume) van de frequentiegegevens
        for (let i = 0; i < frequencyData.length; i++) {
            sum += frequencyData[i];
        }
        let average = sum / frequencyData.length; // Gemiddelde volume (0-255)

        const logoElement = document.querySelector(logoElementSelector);
        if (logoElement) {
            // --- Krijg de huidige sliderwaarde voor het volume-effect op de gloed ---
            let currentSliderVolume = $('#volumeSlider').val() / 100; // Converteer naar 0.0 - 1.0

            // --- UPDATE GLOED INTENSITEIT (BLUR EN SPREAD) GEBASEERD OP VOLUME ---
            let normalizedAverage = average / 255;
            let aggressiveAverage = Math.pow(normalizedAverage, 2.0); // Maak de respons agressiever

            // Combineer de muziek-amplitude met de slider-volume
            let effectiveAverageFactor = aggressiveAverage * currentSliderVolume; // Dit is de factor die de gloed aanstuurt

            let mappedBlur = effectiveAverageFactor * (maxGlowBlur - baseGlowBlur) + baseGlowBlur; // Schaalt naar basis-max
            let mappedSpread = effectiveAverageFactor * (maxGlowSpread - baseGlowSpread) + baseGlowSpread; // Schaalt naar basis-max

            // Zorg ervoor dat de waardes binnen een redelijk bereik blijven
            mappedBlur = Math.min(Math.max(mappedBlur, baseGlowBlur), maxGlowBlur);
            mappedSpread = Math.min(Math.max(mappedSpread, baseGlowSpread), maxGlowSpread);
            
            // --- LOGICA VOOR KLEURVERANDERING OP "BEAT" ---
            let currentTime = Date.now();
            // Kleur verandert alleen als er geluid is (average > beatThreshold) EN de slider niet op 0 staat
            if (average > beatThreshold && currentSliderVolume > 0 && (currentTime - lastBeatTime > beatCooldown)) {
                currentColorIndex = (currentColorIndex + 1) % rainbowColors.length; // Ga naar de volgende kleur
                lastBeatTime = currentTime; // Reset de cooldown timer
            }

            // --- Stel de box-shadow DIRECT in met de berekende waarden en de HUIDIGE kleur ---
            // ALS DE SLIDER OP NUL STAAT, OF ALS ER GEEN GELUID IS EN DE SLIDER OOK OP NUL STAAT, ZET DE GLOED UIT.
            if (currentSliderVolume === 0 || (average === 0 && currentSliderVolume === 0)) {
                 logoElement.style.boxShadow = `0 0 0px 0px rgba(0,0,0,0)`; // Helemaal uit, geen glow
            } else {
                 logoElement.style.boxShadow = `0 0 ${mappedBlur}px ${mappedSpread}px ${rainbowColors[currentColorIndex]}`;
            }
        }
    }
    requestAnimationFrame(updateGlow); // Blijf de gloed updaten
}

// --- MINIMALE LAADTIJD FUNCTIE ---
function checkAndShutdown() {
    if (gameLoaded && minTimeElapsed) {
        // Als het spel geladen is EN de minimale tijd is verstreken, sluit het laadscherm af
        window.location.replace("about:blank");
    }
}
// --- EINDE MINIMALE LAADTIJD FUNCTIE ---

// --- VOLUME SLIDER LOGICA ---
$(document).ready(function() {
    // Initialiseer het icoon op basis van de startwaarde van de schuifregelaar
    let initialSliderValue = $('#volumeSlider').val();
    let initialIconClass = 'fas fa-volume-mute';
    if (initialSliderValue > 0) {
        initialIconClass = 'fas fa-volume-down';
    }
    if (initialSliderValue >= 50) {
        initialIconClass = 'fas fa-volume-up';
    }
    $('.sounds .icon i').removeClass().addClass(initialIconClass);

    $('#volumeSlider').on('input', function() {
        let sliderValue = $(this).val(); // Haal de waarde op (0-100)
        let volume = sliderValue / 100; // Converteer naar een bereik van 0.0 tot 1.0

        if (song) {
            song.volume = volume; // Stel het volume van de achtergrondmuziek in
            console.log("Slider bewogen. Muziekvolume ingesteld op:", song.volume); // DEBUG LOG
        } else {
            console.warn("Slider bewogen, maar 'song' Audio object is niet beschikbaar."); // DEBUG LOG
        }

        // Optioneel: Als je ook het YouTube-volume wilt regelen met deze slider
        // if (player && player.setVolume) {
        //     player.setVolume(sliderValue); // YouTube player gebruikt 0-100 direct
        // }

        // Update icon based on volume
        let iconClass = 'fas fa-volume-mute';
        if (sliderValue > 0) {
            iconClass = 'fas fa-volume-down';
        }
        if (sliderValue >= 50) {
            iconClass = 'fas fa-volume-up';
        }
        $('.sounds .icon i').removeClass().addClass(iconClass);
    });
});
// --- EINDE VOLUME SLIDER LOGICA ---


setup();