Config = {}; // Don't touch

// *** BELANGRIJK: VERVANG DIT MET HET IP-ADRES EN DE POORT VAN JE VIBEGAMES SERVER ***
// Voorbeeld: "192.168.1.100:30120" of "play.mijnvibegamesserver.nl:30120"
Config.ServerIP = "localhost:30120"; // Pas deze regel aan!

// Social media buttons on the left side
Config.Socials = [
    {name: "discord", label: "Discord", description: "Soon", icon: "assets/media/icons/discord.png", link: "Soon"},
    {name: "tiktok", label: "Tiktok", description: "Soon", icon: "assets/media/icons/tiktok.png", link: "Soon"},
    {name: "tebex", label: "Tebex", description: "Soon", icon: "assets/media/icons/tebex.png", link: "Soon"},
];

Config.HideoverlayKeybind = 112 // JS key code https://keycode.info
Config.CustomBindText = "F1"; // leave as "" if you don't want the bind text in html to be statically set

// Staff list
Config.Staff = [
    {name: "[SZR]Tempo.-", description: "Management/Development", color: "#fff", image: "assets/media/tempo.png"},
    {name: "[SZR]Jorick.-", description: "Management", color: "#0195FD", image: "assets/media/jorick.png"},
];

// Categories
Config.Categories = [
    {label: "Social Media", default: true},
    {label: "Staff", default: false}
];

// Music - NIEUW: Voeg een array toe voor de muziekbestanden, corresponderend met de video's
Config.Songs = [
    "song.mp3", // Nummer voor Video 1. Zorg dat deze bestaat in assets/media/
    "song2.mp3" // Nummer voor Video 2. Zorg dat deze bestaat in assets/media/
];